# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['learningpython_org']

package_data = \
{'': ['*']}

install_requires = \
['Django>=4.0.6,<5.0.0', 'black>=22.6.0,<23.0.0', 'flake8>=4.0.1,<5.0.0']

setup_kwargs = {
    'name': 'learningpython.org',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
